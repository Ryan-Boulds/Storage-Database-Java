import java.util.Map;

public class SQLGenerator {
    public static String formatDeviceSQL(Map<String, String> data) {
        StringBuilder sql = new StringBuilder("INSERT INTO Inventory (Device_Name, Device_Type, Brand, Model, Serial_Number, Building_Location, Room_Desk, Specification, Processor_Type, Storage_Capacity, Network_Address, OS_Version, Department, Added_Memory, Status, Assigned_User, Warranty_Expiry_Date, Last_Maintenance, Maintenance_Due, Date_Of_Purchase, Purchase_Cost, Vendor, Memory_RAM) VALUES (");
        String[] fields = {"Device_Name", "Device_Type", "Brand", "Model", "Serial_Number", "Building_Location", "Room_Desk", "Specification", "Processor_Type", "Storage_Capacity", "Network_Address", "OS_Version", "Department", "Added_Memory", "Status", "Assigned_User", "Warranty_Expiry_Date", "Last_Maintenance", "Maintenance_Due", "Date_Of_Purchase", "Purchase_Cost", "Vendor", "Memory_RAM"};
        for (int i = 0; i < fields.length; i++) {
            String value = data.get(fields[i]);
            if (value == null || value.trim().isEmpty()) {
                sql.append("NULL");
            } else if (fields[i].contains("Date")) {
                sql.append("#").append(value).append("#"); // Access uses #MM/DD/YYYY# for dates
            } else if (fields[i].equals("Added_Memory")) {
                if (value.equals("TRUE")) {
                    sql.append("1");
                } else if (value.equals("FALSE")) {
                    sql.append("0");
                } else {
                    sql.append("NULL");
                }
            } else if (fields[i].equals("Purchase_Cost")) {
                sql.append(value);
            } else {
                sql.append("'").append(value.replace("'", "''")).append("'");
            }
            if (i < fields.length - 1) {
                sql.append(", ");
            }
        }
        sql.append(");");
        return sql.toString();
    }

    public static String formatPeripheralSQL(Map<String, String> data) {
        StringBuilder sql = new StringBuilder("INSERT INTO PeripheralInventory (Peripheral_Name, Peripheral_Type, Brand, Model, Serial_Number, Associated_PC, Status, Date_Of_Purchase, Warranty_Expiry_Date, Maintenance_Due) VALUES (");
        String[] fields = {"Peripheral_Name", "Peripheral_Type", "Brand", "Model", "Serial_Number", "Associated_PC", "Status", "Date_Of_Purchase", "Warranty_Expiry_Date", "Maintenance_Due"};
        for (int i = 0; i < fields.length; i++) {
            String value = data.get(fields[i]);
            if (value == null || value.trim().isEmpty()) {
                sql.append("NULL");
            } else if (fields[i].contains("Date")) {
                sql.append("#").append(value).append("#"); // Access uses #MM/DD/YYYY# for dates
            } else {
                sql.append("'").append(value.replace("'", "''")).append("'");
            }
            if (i < fields.length - 1) {
                sql.append(", ");
            }
        }
        sql.append(");");
        return sql.toString();
    }
}